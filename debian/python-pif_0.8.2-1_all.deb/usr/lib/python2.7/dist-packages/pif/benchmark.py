__title__ = 'pif.benchmark'
__author__ = 'Artur Barseghyan'
__copyright__ = 'Copyright (c) 2013-2016 Artur Barseghyan'
__license__ = 'GPL 2.0/LGPL 2.1'
__all__ = ('run_benchmark_test',)


def run_benchmark_test():
    """Run the benchmark test to identify the fastest provider."""
