from __future__ import absolute_import

from .utils import get_public_ip

__title__ = 'pif'
__version__ = '0.8.2'
__build__ = 0x00000e
__author__ = 'Artur Barseghyan'
__copyright__ = 'Copyright (c) 2013-2016 Artur Barseghyan'
__license__ = 'GPL 2.0/LGPL 2.1'
# __all__ = ('get_public_ip',)
